from fastapi import FastAPI
from pydantic import BaseModel
from shared.logging import setup_logging

setup_logging("ocr-service")
app = FastAPI()
_model = None


class SolveRequest(BaseModel):
    image: str


@app.post("/solve")
async def solve(req: SolveRequest):
    return {"text": "", "note": "install requirements-ai.txt and place model"}


@app.get("/health")
async def health():
    return {"status": "ok", "model_loaded": _model is not None}
