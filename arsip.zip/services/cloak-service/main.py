from contextlib import asynccontextmanager
from fastapi import FastAPI
from pydantic import BaseModel
from shared.logging import setup_logging

setup_logging("cloak-service")
sessions = {}


@asynccontextmanager
async def lifespan(app):
    yield
    for s in list(sessions.values()):
        try:
            await s["browser"].close()
        except Exception:
            pass
    sessions.clear()


app = FastAPI(lifespan=lifespan)


class NavigateRequest(BaseModel):
    url: str
    proxy: str | None = None
    session_id: str | None = None


@app.post("/navigate")
async def navigate(req: NavigateRequest):
    try:
        from cloakbrowser import launch_async
    except ImportError:
        return {"session_id": "unavailable", "captcha_detected": True,
                "strategy": "needs_solve", "note": "cloakbrowser not installed"}
    import uuid
    sid = req.session_id or str(uuid.uuid4())
    browser = await launch_async(headless=True, humanize=True, proxy=req.proxy)
    page = await browser.new_page()
    await page.goto(req.url, wait_until="networkidle")
    detected = await page.evaluate(
        "() => !!document.querySelector('[class*="captcha"]')"
    )
    sessions[sid] = {"browser": browser, "page": page}
    return {"session_id": sid, "captcha_detected": detected,
            "strategy": "prevention" if not detected else "needs_solve"}


@app.get("/health")
async def health():
    return {"status": "ok", "active_sessions": len(sessions)}
