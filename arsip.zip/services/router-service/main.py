from fastapi import FastAPI
from pydantic import BaseModel
from shared.logging import setup_logging

setup_logging("router-service")
app = FastAPI()


class RouteRequest(BaseModel):
    url: str
    captcha_type: str
    sitekey: str | None = None
    previous_attempts: int = 0


@app.post("/route")
async def route(req: RouteRequest):
    if req.captcha_type in ("altcha", "friendly"):
        return {"strategy": "free_solver", "confidence": 0.99,
                "fallback": "external_api", "reasoning": "PoW local"}
    if req.captcha_type == "image":
        return {"strategy": "ocr", "confidence": 0.8,
                "fallback": "vision_llm", "reasoning": "Try OCR"}
    return {"strategy": "prevention", "confidence": 0.5,
            "fallback": "external_api", "reasoning": "Default"}


@app.get("/health")
async def health():
    return {"status": "ok"}
