package main

import (
    "encoding/json"
    "log"
    "net/http"
    "os"
)

func solveHandler(w http.ResponseWriter, r *http.Request) {
    json.NewEncoder(w).Encode(map[string]interface{}{"score": 0.0})
}

func healthHandler(w http.ResponseWriter, r *http.Request) {
    json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
}

func main() {
    mux := http.NewServeMux()
    mux.HandleFunc("/solve", solveHandler)
    mux.HandleFunc("/health", healthHandler)
    port := os.Getenv("WASM_PORT")
    if port == "" { port = "9004" }
    log.Printf("WASM on :%s", port)
    log.Fatal(http.ListenAndServe(":"+port, mux))
}
