from fastapi import FastAPI
from pydantic import BaseModel
from shared.logging import setup_logging

setup_logging("vision-service")
app = FastAPI()
_model = None


class GridRequest(BaseModel):
    image: str
    prompt: str
    grid_size: int = 4


class TextRequest(BaseModel):
    image: str


@app.post("/solve-grid")
async def solve_grid(req: GridRequest):
    return {"cells": [], "count": 0, "note": "place Qwen model first"}


@app.post("/solve-text")
async def solve_text(req: TextRequest):
    return {"text": "", "note": "place Qwen model first"}


@app.get("/health")
async def health():
    return {"status": "ok", "model_loaded": _model is not None}
