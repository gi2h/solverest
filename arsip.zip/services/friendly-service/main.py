import time
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from shared.logging import setup_logging
from solvers.friendly_solver import solve_friendly

setup_logging("friendly-service")
app = FastAPI()


class SolveRequest(BaseModel):
    challenge: str
    difficulty: int = 16
    max_nonce: int = 10_000_000


@app.post("/solve")
async def solve(req: SolveRequest):
    t0 = time.time()
    sol = solve_friendly(req.challenge, req.difficulty, req.max_nonce)
    if not sol:
        raise HTTPException(404, "no_solution_found")
    return {"solution": sol, "elapsed": time.time() - t0}


@app.get("/health")
async def health():
    return {"status": "ok"}
