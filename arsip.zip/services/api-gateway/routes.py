import time
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import PlainTextResponse
from shared.config import get_settings
from shared.models import TaskStatus, TaskType
from shared.queue import TaskQueue

router = APIRouter()


async def verify_key(key: str = Query(...)) -> str:
    if key != get_settings().api_key:
        raise HTTPException(403, "ERROR_WRONG_USER_KEY")
    return key


def get_q(request: Request) -> TaskQueue:
    return request.app.state.queue


@router.post("/in.php", response_class=PlainTextResponse)
async def submit(request: Request, queue: TaskQueue = Depends(get_q),
                 api_key: str = Depends(verify_key)):
    form = await request.form()
    method = form.get("method", "")
    tt, payload = _parse(method, form)
    task_id = await queue.enqueue(tt, payload)
    return f"OK|{task_id}"


@router.post("/res.php", response_class=PlainTextResponse)
async def result(action: str = Query("get"), id: str = Query(...),
                 queue: TaskQueue = Depends(get_q),
                 api_key: str = Depends(verify_key)):
    t = await queue.get(id)
    if not t:
        return "ERROR_WRONG_ID"
    s = t.get("status")
    if s in (TaskStatus.PENDING.value, TaskStatus.PROCESSING.value):
        return "CAPCHA_NOT_READY"
    if s == TaskStatus.DONE.value:
        return f"OK|{t.get('result', '')}"
    return f"ERROR|{t.get('error', 'UNKNOWN')}"


def _parse(method, form):
    if method == "userrecaptcha":
        return TaskType.RECAPTCHA, {"sitekey": form.get("googlekey", ""),
                                    "url": form.get("pageurl", "")}
    if method == "turnstile":
        return TaskType.TURNSTILE, {"sitekey": form.get("sitekey", ""),
                                    "url": form.get("pageurl", "")}
    if method == "base64":
        return TaskType.IMAGE, {"body": form.get("body", "")}
    if method == "altcha":
        return TaskType.ALTCHA, {"challenge": form.get("challenge", "")}
    if method == "friendly":
        return TaskType.FRIENDLY, {"challenge": form.get("challenge", "")}
    raise HTTPException(400, "ERROR_WRONG_METHOD")


@router.get("/health")
async def health(queue: TaskQueue = Depends(get_q)):
    from shared.redis_client import get_redis
    checks = {}
    try:
        r = await get_redis()
        await r.ping()
        checks["redis"] = "ok"
        for tt in TaskType:
            checks[f"queue:{tt.value}"] = await r.xlen(tt.value)
    except Exception as e:
        checks["redis"] = f"error: {e}"
    return {"status": "ok", "checks": checks, "ts": time.time()}
