from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from services.api_gateway.routes import router
from shared.logging import setup_logging, new_correlation_id
from shared.metrics import render_metrics
from shared.queue import TaskQueue
from shared.redis_client import get_redis, close_redis

setup_logging("api-gateway")


@asynccontextmanager
async def lifespan(app):
    await get_redis()
    q = TaskQueue()
    await q.connect()
    app.state.queue = q
    yield
    await q.close()
    await close_redis()


app = FastAPI(title="Fortress Captcha API", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])


@app.middleware("http")
async def cid_mw(request: Request, call_next):
    cid = request.headers.get("X-Correlation-ID") or new_correlation_id()
    resp = await call_next(request)
    resp.headers["X-Correlation-ID"] = cid
    return resp


app.include_router(router)


@app.get("/metrics")
async def metrics():
    body, ct = render_metrics()
    return Response(content=body, media_type=ct)
