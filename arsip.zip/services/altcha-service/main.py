import time
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from shared.logging import setup_logging
from solvers.altcha_solver import solve_altcha

setup_logging("altcha-service")
app = FastAPI()


class SolveRequest(BaseModel):
    challenge: str
    max_iterations: int = 5_000_000


@app.post("/solve")
async def solve(req: SolveRequest):
    t0 = time.time()
    sol = solve_altcha(req.challenge, req.max_iterations)
    if not sol:
        raise HTTPException(404, "no_solution_found")
    return {"solution": sol, "elapsed": time.time() - t0}


@app.get("/health")
async def health():
    return {"status": "ok"}
