#!/usr/bin/env python3
"""Download AI models for Fortress Captcha."""
import argparse, os, sys, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MODELS = ROOT / "models"
QWEN_REPO = "Qwen/Qwen3.5-9B"
QWEN_DIR = MODELS / "qwen-vision"
MOBILE_URLS = [
    "https://huggingface.co/Blast02/ocr-special-characters-classification-mobilenetv2/resolve/main/mobilenetv2_captcha.h5",
]
MOBILE_FILE = MODELS / "mobilenetv2_captcha.h5"


def dl(url, dest, label=""):
    if dest.exists() and dest.stat().st_size > 0:
        print(f"  OK {dest.name} ({dest.stat().st_size/1e6:.1f} MB)")
        return True
    dest.parent.mkdir(parents=True, exist_ok=True)
    print(f"  Downloading {label or url}...")
    try:
        with urllib.request.urlopen(url, timeout=60) as r:
            total = int(r.headers.get("Content-Length", 0))
            got = 0
            with open(dest, "wb") as f:
                while True:
                    buf = r.read(262144)
                    if not buf:
                        break
                    f.write(buf)
                    got += len(buf)
                    if total:
                        print(f"\r    {got/total*100:5.1f}% ({got/1e6:.1f} MB)", end="")
            print()
        print(f"  OK {dest}")
        return True
    except Exception as e:
        print(f"  FAIL: {e}")
        if dest.exists():
            dest.unlink()
        return False


def dl_qwen():
    print(f"\n[1/2] Qwen3.5-9B -> {QWEN_DIR}")
    if QWEN_DIR.exists() and any(QWEN_DIR.iterdir()):
        print("  Already present")
        return True
    try:
        from huggingface_hub import snapshot_download
    except ImportError:
        print("  FAIL: pip install huggingface-hub")
        return False
    try:
        snapshot_download(
            repo_id=QWEN_REPO,
            local_dir=str(QWEN_DIR),
            token=os.environ.get("HF_TOKEN"),
            ignore_patterns=["*.msgpack", "*.h5", "*.ot", "*.tflite"],
        )
        return True
    except Exception as e:
        print(f"  FAIL: {e}")
        return False


def dl_mobile():
    print(f"\n[2/2] MobileNetV2 -> {MOBILE_FILE}")
    for url in MOBILE_URLS:
        if dl(url, MOBILE_FILE, "MobileNetV2"):
            return True
    return False


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--skip-qwen", action="store_true")
    p.add_argument("--skip-mobilenet", action="store_true")
    a = p.parse_args()
    MODELS.mkdir(parents=True, exist_ok=True)
    results = {}
    if not a.skip_qwen:
        results["qwen"] = dl_qwen()
    if not a.skip_mobilenet:
        results["mobilenet"] = dl_mobile()
    print("\nSummary:")
    for k, v in results.items():
        print(f"  {'OK' if v else 'FAIL'} {k}")
    return 0 if all(results.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
