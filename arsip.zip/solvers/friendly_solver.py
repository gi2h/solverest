import base64, hashlib, struct


def solve_friendly(challenge_b64: str, difficulty: int = 16,
                   max_nonce: int = 10_000_000) -> str | None:
    buf = base64.b64decode(challenge_b64)
    threshold = 1 << (32 - difficulty)
    for nonce in range(max_nonce):
        b = buf + struct.pack(">Q", nonce)
        d = hashlib.blake2b(b, digest_size=32).digest()
        if struct.unpack("<I", d[:4])[0] < threshold:
            return base64.b64encode(b).decode()
    return None
