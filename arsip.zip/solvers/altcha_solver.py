import base64, hashlib, json


def solve_altcha(challenge_json: str, max_iter: int = 5_000_000) -> str | None:
    data = json.loads(challenge_json)
    salt, target = data["salt"], data["challenge"]
    max_n = min(data.get("maxnumber", max_iter), max_iter)
    for number in range(max_n):
        h = hashlib.sha256(f"{salt}{number}".encode()).hexdigest()
        if h == target:
            return base64.b64encode(json.dumps({
                "algorithm": data.get("algorithm", "SHA-256"),
                "challenge": target, "number": number, "salt": salt,
            }).encode()).decode()
    return None
