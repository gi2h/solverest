from abc import ABC, abstractmethod
from typing import Any


class BaseSolver(ABC):
    @abstractmethod
    async def solve(self, payload: dict[str, Any]) -> dict[str, Any]:
        ...
