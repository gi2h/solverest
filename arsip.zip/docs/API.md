# API Reference (2captcha-compatible)

POST /in.php  -> OK|<task_id>
POST /res.php -> OK|<solution> | CAPCHA_NOT_READY | ERROR_<code>
