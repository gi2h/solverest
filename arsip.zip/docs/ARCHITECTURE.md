# Architecture

Layers:
1. Prevention (CloakBrowser)
2. Free solvers (ALTCHA, Friendly Captcha)
3. AI solvers (Vision LLM, OCR)
4. External fallback
