# Deployment

## Railway
Push to GitHub, add each service, set env vars.

## Termux
    pkg install python redis
    pip install -r requirements.txt
    redis-server --daemonize yes
    uvicorn services.api-gateway.main:app --port 8080
