import asyncio
import pytest
import pytest_asyncio


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture
async def redis_client():
    import redis.asyncio as redis
    r = redis.from_url("redis://localhost:6379/15", decode_responses=True)
    try:
        await r.flushdb()
        yield r
        await r.flushdb()
    finally:
        await r.aclose()
