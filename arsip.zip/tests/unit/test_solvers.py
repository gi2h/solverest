import base64, hashlib, json
from solvers.altcha_solver import solve_altcha


def test_altcha_solver():
    salt = "abc"
    target = None
    for n in range(200000):
        h = hashlib.sha256(f"{salt}{n}".encode()).hexdigest()
        if h.startswith("0000"):
            target = h
            break
    if target is None:
        return
    challenge = json.dumps({"algorithm": "SHA-256", "challenge": target,
                            "salt": salt, "maxnumber": 200000})
    sol = solve_altcha(challenge)
    assert sol
    decoded = json.loads(base64.b64decode(sol))
    assert decoded["number"] == n
