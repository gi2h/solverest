from prometheus_client import Counter, Gauge, Histogram, generate_latest, CONTENT_TYPE_LATEST

QUEUE_DEPTH = Gauge("captcha_queue_depth", "Pending tasks", ["queue"])
ACTIVE_WORKERS = Gauge("captcha_active_workers", "Active workers", ["service", "strategy"])
SOLVE_DURATION = Histogram("captcha_solve_duration_seconds", "Solve time", ["type"],
                           buckets=[1, 2, 5, 10, 20, 30, 60, 120])
DEAD_LETTER = Counter("captcha_dead_letter_total", "Dead letters", ["type"])


def render_metrics():
    return generate_latest(), CONTENT_TYPE_LATEST
