from __future__ import annotations
import time, uuid
from enum import Enum
from typing import Any
from pydantic import BaseModel, Field


class TaskType(str, Enum):
    IMAGE = "task:img"
    RECAPTCHA = "task:rec"
    TURNSTILE = "task:tst"
    ALTCHA = "task:alt"
    FRIENDLY = "task:friendly"


class TaskStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    DONE = "done"
    FAILED = "failed"


class Task(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    type: TaskType
    status: TaskStatus = TaskStatus.PENDING
    payload: dict[str, Any]
    result: dict[str, Any] | None = None
    error: str | None = None
    attempts: int = 0
    created_at: float = Field(default_factory=time.time)
