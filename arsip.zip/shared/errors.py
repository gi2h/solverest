class FortressError(Exception):
    code = "FORTRESS_ERROR"


class TaskNotFound(FortressError):
    code = "TASK_NOT_FOUND"


class SolverFailed(FortressError):
    code = "SOLVER_FAILED"


class QueueError(FortressError):
    code = "QUEUE_ERROR"
