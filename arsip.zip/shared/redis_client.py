import redis.asyncio as redis
from shared.config import get_settings

_pool = None


async def get_redis() -> redis.Redis:
    global _pool
    if _pool is None:
        s = get_settings()
        _pool = redis.from_url(
            s.redis_url, decode_responses=True,
            max_connections=s.redis_max_connections,
        )
    return _pool


async def close_redis() -> None:
    global _pool
    if _pool is not None:
        await _pool.aclose()
        _pool = None
