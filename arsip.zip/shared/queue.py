import json, time, uuid
from typing import Any
import redis.asyncio as redis
from redis.exceptions import ResponseError
from shared.config import get_settings
from shared.models import TaskStatus, TaskType


class TaskQueue:
    GROUP = "fortress-workers"
    DLQ = "task:dead-letter"

    def __init__(self, redis_url: str | None = None):
        s = get_settings()
        self.url = redis_url or s.redis_url
        self.maxlen = s.redis_stream_maxlen
        self._r: redis.Redis | None = None

    async def connect(self):
        self._r = redis.from_url(self.url, decode_responses=True)
        await self._r.ping()
        for t in TaskType:
            try:
                await self._r.xgroup_create(t.value, self.GROUP, id="0", mkstream=True)
            except ResponseError as e:
                if "BUSYGROUP" not in str(e):
                    raise

    async def enqueue(self, task_type: TaskType, payload: dict) -> str:
        tid = str(uuid.uuid4())
        await self._r.hset(f"task:{tid}", mapping={
            "id": tid, "type": task_type.value,
            "status": TaskStatus.PENDING.value,
            "payload": json.dumps(payload),
            "created_at": str(time.time()), "attempts": "0",
        })
        await self._r.expire(f"task:{tid}", 3600)
        await self._r.xadd(task_type.value, {"task_id": tid},
                           maxlen=self.maxlen, approximate=True)
        return tid

    async def get(self, tid: str) -> dict | None:
        return await self._r.hgetall(f"task:{tid}") or None

    async def update(self, tid: str, **kw):
        await self._r.hset(f"task:{tid}", mapping={k: str(v) for k, v in kw.items()})

    async def dequeue(self, tt: TaskType, consumer: str, block_ms: int = 5000):
        res = await self._r.xreadgroup(self.GROUP, consumer,
                                       {tt.value: ">"}, count=1, block=block_ms)
        if not res or not res[0][1]:
            return None
        msg_id, fields = res[0][1][0]
        task = await self._r.hgetall(f"task:{fields['task_id']}")
        if not task:
            await self._r.xack(tt.value, self.GROUP, msg_id)
            return None
        return msg_id, task

    async def ack(self, tt: TaskType, msg_id: str):
        await self._r.xack(tt.value, self.GROUP, msg_id)

    async def requeue(self, tt: TaskType, tid: str):
        await self._r.xadd(tt.value, {"task_id": tid}, maxlen=self.maxlen)

    async def move_to_dead_letter(self, tid: str, error: str):
        await self._r.xadd(self.DLQ, {"task_id": tid, "error": error},
                           maxlen=1000)
        await self.update(tid, status=TaskStatus.FAILED.value, error=error)

    async def close(self):
        if self._r:
            await self._r.aclose()
