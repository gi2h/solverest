import base64, time


def b64enc(b: bytes) -> str:
    return base64.b64encode(b).decode()


def b64dec(s: str) -> bytes:
    return base64.b64decode(s)


def now() -> float:
    return time.time()
