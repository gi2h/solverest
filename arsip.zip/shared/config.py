from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", case_sensitive=False, extra="ignore",
    )
    env: str = "development"
    log_level: str = "INFO"
    workers: int = 4
    redis_url: str = "redis://localhost:6379/0"
    redis_max_connections: int = 50
    redis_stream_maxlen: int = 10000
    api_host: str = "0.0.0.0"
    api_port: int = 8080
    api_key: str = "dev-key"
    cloak_host: str = "cloak-service.railway.internal"
    cloak_port: int = 9001
    vision_host: str = "vision-service.railway.internal"
    vision_port: int = 9002
    ocr_host: str = "ocr-service.railway.internal"
    ocr_port: int = 9003
    altcha_host: str = "altcha-service.railway.internal"
    altcha_port: int = 9005
    friendly_host: str = "friendly-service.railway.internal"
    friendly_port: int = 9006
    router_host: str = "router-service.railway.internal"
    router_port: int = 9007
    vision_model_path: str = "/app/models/qwen-vision"
    vision_device: str = "cpu"
    ocr_model_path: str = "/app/models/mobilenetv2_captcha.h5"
    hf_token: str | None = None
    openai_api_key: str | None = None
    router_model: str = "gpt-4o"

    def service_url(self, name: str) -> str:
        host = getattr(self, f"{name}_host")
        port = getattr(self, f"{name}_port")
        return f"http://{host}:{port}"


@lru_cache
def get_settings() -> Settings:
    return Settings()
