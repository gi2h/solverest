import json, logging, sys, uuid
from contextvars import ContextVar

cid_var: ContextVar[str] = ContextVar("cid", default="")
svc_var: ContextVar[str] = ContextVar("svc", default="unknown")


class JsonFormatter(logging.Formatter):
    def format(self, record):
        return json.dumps({
            "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%SZ"),
            "level": record.levelname,
            "service": svc_var.get(),
            "cid": cid_var.get(),
            "logger": record.name,
            "message": record.getMessage(),
        }, default=str)


def setup_logging(service: str, level: str = "INFO") -> None:
    svc_var.set(service)
    h = logging.StreamHandler(sys.stdout)
    h.setFormatter(JsonFormatter())
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(h)
    root.setLevel(level.upper())


def new_correlation_id() -> str:
    cid = str(uuid.uuid4())
    cid_var.set(cid)
    return cid
