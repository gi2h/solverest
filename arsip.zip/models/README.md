# Models

Auto-downloaded by `python scripts/download_models.py`:
- models/qwen-vision/          Qwen3.5-9B (~18 GB, Linux only)
- models/mobilenetv2_captcha.h5 MobileNetV2 OCR (~30 MB)
