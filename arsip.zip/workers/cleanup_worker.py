import asyncio
from shared.logging import setup_logging
from shared.redis_client import get_redis, close_redis

setup_logging("cleanup-worker")


async def loop():
    r = await get_redis()
    while True:
        try:
            if await r.xlen("task:dead-letter") > 100:
                await r.xtrim("task:dead-letter", maxlen=1000, approximate=True)
            await asyncio.sleep(300)
        except Exception:
            await asyncio.sleep(60)


if __name__ == "__main__":
    try:
        asyncio.run(loop())
    finally:
        pass
