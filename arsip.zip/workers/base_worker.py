import asyncio, signal, time, uuid
from abc import ABC, abstractmethod
from shared.logging import setup_logging, new_correlation_id
from shared.metrics import ACTIVE_WORKERS
from shared.models import TaskStatus, TaskType
from shared.queue import TaskQueue
from shared.redis_client import get_redis


class BaseWorker(ABC):
    def __init__(self, name: str, task_type: TaskType):
        self.name = name
        self.task_type = task_type
        self.wid = f"{name}-{uuid.uuid4().hex[:8]}"
        self.queue = TaskQueue()
        self.running = True
        setup_logging(name)

    @abstractmethod
    async def solve(self, task: dict) -> dict:
        ...

    async def _hb(self):
        r = await get_redis()
        while self.running:
            try:
                await r.setex(f"worker:hb:{self.wid}", 30, str(time.time()))
            except Exception:
                pass
            await asyncio.sleep(10)

    async def run(self):
        await self.queue.connect()
        ACTIVE_WORKERS.labels(service=self.name,
                              strategy=self.task_type.value).inc()
        asyncio.create_task(self._hb())
        while self.running:
            try:
                item = await self.queue.dequeue(self.task_type, self.wid)
                if not item:
                    continue
                msg_id, task = item
                tid = task["id"]
                new_correlation_id()
                await self.queue.update(tid, status=TaskStatus.PROCESSING.value)
                try:
                    result = await asyncio.wait_for(self.solve(task), timeout=120)
                    await self.queue.update(tid, status=TaskStatus.DONE.value,
                                            result=result.get("result", ""))
                    await self.queue.ack(self.task_type, msg_id)
                except asyncio.TimeoutError:
                    await self._fail(task, msg_id, "TIMEOUT")
                except Exception as e:
                    await self._fail(task, msg_id, str(e))
            except asyncio.CancelledError:
                break
            except Exception:
                await asyncio.sleep(1)
        await self.queue.close()

    async def _fail(self, task, msg_id, error):
        tid = task["id"]
        attempts = int(task.get("attempts", 0))
        if attempts < 3:
            await self.queue.update(tid, attempts=attempts + 1)
            await self.queue.requeue(self.task_type, tid)
        else:
            await self.queue.move_to_dead_letter(tid, error)
        await self.queue.ack(self.task_type, msg_id)

    def stop(self):
        self.running = False


def run_worker(w: BaseWorker):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.add_signal_handler(signal.SIGTERM, w.stop)
    loop.add_signal_handler(signal.SIGINT, w.stop)
    try:
        loop.run_until_complete(w.run())
    finally:
        loop.close()
