from shared.models import TaskType
from workers.base_worker import BaseWorker, run_worker


class TokenWorker(BaseWorker):
    def __init__(self):
        super().__init__("token-worker", TaskType.RECAPTCHA)

    async def solve(self, task: dict) -> dict:
        return {"result": ""}


if __name__ == "__main__":
    run_worker(TokenWorker())
