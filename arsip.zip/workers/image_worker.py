from shared.models import TaskType
from workers.base_worker import BaseWorker, run_worker


class ImageWorker(BaseWorker):
    def __init__(self):
        super().__init__("image-worker", TaskType.IMAGE)

    async def solve(self, task: dict) -> dict:
        # Placeholder: integrate OCR / Vision
        return {"result": ""}


if __name__ == "__main__":
    run_worker(ImageWorker())
