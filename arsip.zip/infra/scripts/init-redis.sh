#!/usr/bin/env bash
set -euo pipefail
HOST="${REDIS_HOST:-localhost}"
PORT="${REDIS_PORT:-6379}"
for stream in task:img task:rec task:tst task:alt task:friendly; do
    redis-cli -h "$HOST" -p "$PORT" \
        XGROUP CREATE "$stream" "fortress-workers" "0" MKSTREAM 2>/dev/null || true
done
echo "Redis consumer groups initialized."
